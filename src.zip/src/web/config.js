const config = {
  apiUrl: 'http://localhost:3333'
};

export default config;